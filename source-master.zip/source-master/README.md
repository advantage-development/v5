# Advantage
Name : Advantage

Symbol : USDA

Algorithm : PoW + PoS + Masternode

Block time : 60S

Block size : 40kB

Coin base maturity :  1 block

Diffculty Target : 10 blocks

Stake Minimum Age: 24 Hours

Masternode Requires : 1,000,000 USDA

RPCPORT = 53211

PORT = 11235

Masternode Rewards: 

25% of Block Fees + Stable Block Reward (1 USDA)
